import aiml
from py2neo import Graph, Node, Relationship

# Initialize the AIML kernel
kernel = aiml.Kernel()

# Load the AIML file
try:
    kernel.learn("text.aiml")
    print("AIML file loaded successfully.")
except Exception as e:
    print(f"Error loading AIML file: {e}")

# Connect to the Neo4j database
graph = Graph("bolt://localhost:7687", auth=("neo4j", "12345678"))

def add_book(book_title):
    book_node = Node("Book", title=book_title)
    graph.create(book_node)
    print(f"Book '{book_title}' added to the library.")

def add_person(person_name):
    person_node = Node("Person", name=person_name)
    graph.create(person_node)
    print(f"Person '{person_name}' added to the library.")

def borrow_book(book_title, person_name):
    # Query to check if the book exists and if it's currently borrowed
    query = """
    MATCH (b:Book {title: $title})
    OPTIONAL MATCH (b)-[:BORROWED_BY]->(u:Person)
    RETURN b, u
    """
    try:
        result = graph.run(query, title=book_title).data()
    except Exception as e:
        print(f"Error querying the database: {e}")
        return

    if result:
        record = result[0]
        if 'b' not in record or not record['b']:
            print(f"The book '{book_title}' does not exist in our library.")
            return

        if record['u']:
            print(f"The book '{book_title}' is currently borrowed by {record['u']['name']}.")
        else:
            print(f"The book '{book_title}' is available for borrowing.")
            try:
                person_node = graph.nodes.match("Person", name=person_name).first()
                if person_node:
                    book_node = record['b']
                    borrow_rel = Relationship(book_node, "BORROWED_BY", person_node)
                    graph.create(borrow_rel)
                    print(f"The book '{book_title}' has been borrowed by {person_name}.")
                else:
                    print(f"Person '{person_name}' not found in the library.")
            except Exception as e:
                print(f"Error processing the borrow request: {e}")
    else:
        print(f"No records found for the book '{book_title}' in our library.")

        
def return_book(book_title, person_name):
    # Query to check if the book was borrowed by the person
    query = """
    MATCH (b:Book {title: $title})-[:BORROWED_BY]->(u:Person {name: $name})
    RETURN b, u
    """
    try:
        result = graph.run(query, title=book_title, name=person_name).data()
    except Exception as e:
        print(f"Error querying the database: {e}")
        return

    # Check if the result is not empty and contains the expected nodes
    if result and 'b' in result[0] and 'u' in result[0]:
        try:
            # Query to delete the BORROWED_BY relationship
            return_rel_query = """
            MATCH (b:Book {title: $title})-[r:BORROWED_BY]->(u:Person {name: $name})
            DELETE r
            """
            graph.run(return_rel_query, title=book_title, name=person_name)
            print(f"The book '{book_title}' has been returned by {person_name}.")
        except Exception as e:
            print(f"Error updating the database: {e}")
    else:
        # Improved feedback based on the query result
        if not result:
            print(f"The book '{book_title}' was not borrowed by '{person_name}'.")
        elif 'b' not in result[0]:
            print(f"The book '{book_title}' does not exist in our library.")
        elif 'u' not in result[0]:
            print(f"The person '{person_name}' does not exist in our library.")

# Main loop to interact with the user
while True:
    user_input = input("You: ")
    response = kernel.respond(user_input)
    
    print("Bot:", response)  # Print bot's initial response

    action = kernel.getPredicate("action")
    print(f"Action: {action}")  # Debug action
    if action == "add_book":
        book_title = kernel.getPredicate("book_title")
        print(f"Adding book: {book_title}")  # Debug book title
        add_book(book_title)
        kernel.setPredicate("action", "")  # Clear action
    elif action == "add_person":
        person_name = kernel.getPredicate("person_name")
        print(f"Adding person: {person_name}")  # Debug person name
        add_person(person_name)
        kernel.setPredicate("action", "")  # Clear action
    elif action == "borrow_book":
        book_title = kernel.getPredicate("book_title")
        print(f"Borrowing book: {book_title}")  # Debug book title
        person_name = input("Please enter the name of the person borrowing the book: ")
        borrow_book(book_title, person_name)
        kernel.setPredicate("action", "")  # Clear action
        
    elif action == "return_book":
        book_title = kernel.getPredicate("book_title")
        print(f"Returning book: {book_title}")
        person_name = input("Please enter the name of the person returning the book: ")
        return_book(book_title, person_name)
        kernel.setPredicate("action", "")
    else:
        print("Unrecognized action or no action set.")
