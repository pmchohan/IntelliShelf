import aiml

kernel = aiml.Kernel()
kernel.learn("text.aiml")

while True:
    user_input = input("You: ")
    if user_input.lower() == "bye":
        break
    response = kernel.respond(user_input)
    print("bot:", response)
    